package synchronization;

public class Manager {
	public static final int MAX_RESOURCES=5;
	private int availableResources =MAX_RESOURCES;
	
	public int decreaseCount(int count)
	{
		if(availableResources<count)
		{
			return -1;
		}
		else
		{
			availableResources-=count;
			return 0;
		}
		
	}
	
	public void increaseCount(int count)
	{
		availableResources+=count;
	}
	public int getResources()
	{
		return availableResources;
	}
}
